+++
date = '2025-09-24T00:47:30-07:00'
draft = false
title = 'Radio'
+++

## Shortwave QSL Cards

<table>
<tr>
<td>freq.</td>
<td>9330 kHz</td>
</tr>
<tr>
<td>SINPO</td>
<td>44444</td>
</tr>
</table>