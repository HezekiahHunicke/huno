+++
date = '2025-08-21T09:50:25-07:00'
draft = false
title = 'Contact Me'
linkTitle = 'Contact'
+++

```
< my first name > [at] hunicke.com
```

My preferred method of contact is email.

I generally avoid using social media. However, I do have profiles on the following:

- [GitHub / HezekiahHunicke](https://github.com/HezekiahHunicke)
- [LinkedIn / HezekiahHunicke](https://www.linkedin.com/in/hezekiahhunicke/)
- [Discord / HezekiahHunicke](https://discordapp.com/users/1081060702447484938)