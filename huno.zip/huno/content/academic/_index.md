+++
date = '2025-08-20T14:47:36-07:00'
draft = false
title = 'Academic'
+++
This page isn't finished yet!